FILES:
- Thesis_JudithNeve_0070661
  The thesis report, without the title page (in-file hyperlinks work).
- SupplementaryMaterials_JudithNeve_0070661
  The thesis supplementary materials.
- RM_Thesis_JudithNeve_0070661
  The thesis report with the title page (in-file hyperlinks do NOT work).
  Created by collating the title page and Thesis_JudithNeve_0070661.
- RM_Thesis_JudithNeve_0070661_COMPRESSED
  The thesis report with the title page as submitted on Osiris (in-file hyperlinks do NOT work).
  Heavily compressed to fit the file limit.
  Created by compressing RM_Thesis_JudithNeve_0070661.

The content is the same in all three documents with thesis report, but Thesis_JudithNeve_0070661 is the file that offers the best reading experience with:
- working hyperlinks
- working bookmarks
These do not exist in the other versions due to PDF collating and compression required for the Osiris submission.